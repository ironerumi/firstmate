#!/usr/bin/env bash
set -u
# Use the existing self-cleaning fixture builder and execute only directory-lock cases.
eval "$(python3 - <<'PY'
from pathlib import Path
s = Path('tests/fm-extension-binding.test.sh').read_text()
print(s.split('\nif section_enabled coordinator-fail; then')[0])
PY
)"
eval "$(python3 - <<'PY'
from pathlib import Path
s = Path('tests/fm-extension-binding.test.sh').read_text()
print(s[s.index('# The host retires an inherited copied-link directory lifecycle lock'):s.index('\nH_ABSENT=')])
PY
)"
# This macOS filesystem rejects renaming a read-only directory. Seed the
# disposable managed package dataset using the product's transfer digest,
# then drive the unmodified public binding/handshake/verification consumers.
P_GOOD="$PACKAGES/good"
make_package "$P_GOOD" org.example.good ext-good
for lock_mode in native copied; do
  home="$HOMES/public-$lock_mode"
  new_home "$home"
  FM_HOME="$home" "$HOST" pack-transfer "$P_GOOD" > "$TMP_ROOT/transfer.json" || exit $?
  python3 - "$TMP_ROOT/transfer.json" "$P_GOOD" "$home" <<'PY'
import json, pathlib, shutil, sys
manifest=json.load(open(sys.argv[1]))['manifest']
root=pathlib.Path(sys.argv[3])/'data/extensions/packages'/manifest['extension_id']/manifest['extension_version']/manifest['package_digest'].split(':')[1]
shutil.copytree(sys.argv[2],root)
parent=root.parent
home=pathlib.Path(sys.argv[3])
while parent != home:
    parent.chmod(0o700)
    parent=parent.parent
for entry in root.rglob('*'):
    entry.chmod(0o555 if entry.is_dir() or entry.stat().st_mode & 0o111 else 0o444)
root.chmod(0o555)
print('Prepared immutable package dataset:',manifest['package_digest'])
PY
  printf '\nPUBLIC extension-bind (%s locks)\n' "$lock_mode"
  if [ "$lock_mode" = copied ]; then
    PATH="$DIRLOCK_NODE_BIN:$PATH" FM_HOME="$home" "$PROCEVENT" extension-bind bind "$P_GOOD" --adapter ext-good --trust-same-user-code --timeout-ms 1000 || exit $?
  else
    FM_HOME="$home" "$PROCEVENT" extension-bind bind "$P_GOOD" --adapter ext-good --trust-same-user-code --timeout-ms 1000 || exit $?
  fi
  FM_HOME="$home" "$HOST" list || exit $?
  FM_HOME="$home" "$HOST" verify org.example.good || exit $?
  [ ! -e "$home/state/procevent/.extension-binding-lifecycle.lock" ] || fail "public lifecycle lock remains held"
  [ -z "$(find "$home/state/procevent" -name '*.owner.*' -print)" ] || fail "public lifecycle lock owner residue"
  printf 'Persisted binding: '
  python3 - "$home/config/extensions.d/org.example.good.json" <<'PY'
import json,sys
v=json.load(open(sys.argv[1]))
print(json.dumps({k:v[k] for k in ['extension_id','extension_version','package_digest','host_protocol','capabilities']}))
PY
  printf 'Lifecycle release: public lock and all owner generations absent\n'
done
