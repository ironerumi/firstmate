#!/usr/bin/env bash
set -eu
ROOT=$PWD
CASE_ROOT="$ROOT/.gate-test-tmp/session-live"
mkdir -p "$CASE_ROOT"
trap 'rm -rf "$CASE_ROOT"' EXIT
unset FM_STATE_OVERRIDE FM_ROOT_OVERRIDE FM_DATA_OVERRIDE FM_CONFIG_OVERRIDE FM_PROJECTS_OVERRIDE
export GATE_REAL_LN=$(command -v ln)
for mode in native copied denied; do
  export FM_HOME="$CASE_ROOT/$mode"
  mkdir -p "$FM_HOME/state" "$FM_HOME/fakebin"
  export GATE_LN_LOG="$FM_HOME/ln.log" GATE_LINK_MODE="$mode"
  if [ "$mode" != native ]; then
    printf '#!/usr/bin/env bash\nif [ "$1" = -s ]; then\n printf "%%s %%s -> %%s\\n" "$GATE_LINK_MODE" "$2" "$3" >> "$GATE_LN_LOG"\n if [ "$GATE_LINK_MODE" = denied ]; then exit 1; fi\n exec cp -R "$2" "$3"\nfi\nexec "$GATE_REAL_LN" "$@"\n' > "$FM_HOME/fakebin/ln"
    chmod +x "$FM_HOME/fakebin/ln"
  fi
  export PATH="$FM_HOME/fakebin:$PATH"
  printf '\n=== real fm-lock CLI: %s symlink boundary ===\n' "$mode"
  bash "$ROOT/bin/fm-lock.sh"
  bash "$ROOT/bin/fm-lock.sh" status
  bash "$ROOT/bin/fm-lock.sh"
  printf 'Persisted session anchor: %s\n' "$(head -n 1 "$FM_HOME/state/.lock")"
  [ ! -e "$FM_HOME/state/.lock.acquire" ]
  mkfifo "$FM_HOME/ready" "$FM_HOME/release"
  exec 7<> "$FM_HOME/ready" 8<> "$FM_HOME/release"
  bash -c '
    . "$1/bin/fm-wake-lib.sh"
    fm_lock_try_acquire "$STATE/.lock.acquire" || exit 10
    printf "holder pid=%s owner=%s\n" "$(cat "$STATE/.lock.acquire/pid")" "$FM_LOCK_OWNER_DIR" >&7
    IFS= read -r _ <&8
    fm_lock_release "$STATE/.lock.acquire"
  ' _ "$ROOT" &
  holder=$!
  IFS= read -r ready <&7
  printf 'Concurrent claim: %s\n' "$ready"
  bash "$ROOT/bin/fm-lock.sh" > "$FM_HOME/waiter.out" 2>&1 &
  waiter=$!
  sleep 2
  kill -0 "$waiter"
  [ "$(cat "$FM_HOME/state/.lock.acquire/pid")" = "$holder" ]
  printf 'Live holder preserved; fm-lock is waiting, not entering its claim section\n'
  printf 'release\n' >&8
  wait "$holder"
  wait "$waiter"
  python3 - "$FM_HOME/waiter.out" <<'PY'
import pathlib,sys
print('After rightful release:',pathlib.Path(sys.argv[1]).read_text().strip())
PY
  exec 7>&- 8>&-
  bash -c '. "$1/bin/fm-wake-lib.sh"; fm_lock_try_create "$STATE/.lock.acquire"; printf "Abandoned claim pid=%s owner=%s\n" "$(cat "$STATE/.lock.acquire/pid")" "$FM_LOCK_OWNER_DIR"' _ "$ROOT"
  printf 'Recovering the exited claim holder through fm-lock CLI:\n'
  bash "$ROOT/bin/fm-lock.sh"
  [ ! -e "$FM_HOME/state/.lock.acquire" ]
  [ -z "$(find "$FM_HOME/state" -name '*.owner.*' -print)" ]
  bash "$ROOT/bin/fm-lock.sh" status
  if [ "$mode" != native ]; then
    [ -s "$GATE_LN_LOG" ]
    printf 'Observed symlink-capability boundary: '
    head -n 1 "$GATE_LN_LOG"
  fi
  printf 'Claim lock and owner generations fully released\n'
done
