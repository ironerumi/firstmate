#!/usr/bin/env bash
. "$GATE_WORKTREE/bin/fm-wake-lib.sh"
eval "$GATE_OLD_REMOVE"
