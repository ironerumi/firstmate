#!/usr/bin/env bash
set -u
eval "$(python3 - <<'PY'
from pathlib import Path
s = Path('tests/fm-watcher-lock.test.sh').read_text()
print(s.split('\ntest_wait_deadline_reaps_a_stopped_child\n')[0])
PY
)"
eval "$(declare -f dirlock_expect | python3 -c 'import sys; print(sys.stdin.read().replace("dirlock_expect", "_gate_dirlock_expect", 1))')"
dirlock_expect() {
  _gate_dirlock_expect "$@"
  printf 'protocol event: %s\n' "$DIRLOCK_EVENT"
}
if [ "${GATE_REGRESSION:-0}" = 1 ]; then
  LIB="$ROOT/tests/.gate-prefixed-lib.sh"
  test_dirlock_d4c_orphan_husk_cleanup_preserves_successor
  exit $?
fi
for scenario in \
 test_lock_single_winner_under_concurrency \
 test_lock_steals_dead_pid_lock \
 test_lock_stale_steal_single_winner_under_concurrency \
 test_lock_reclaims_dead_steal_owner_without_nested_markers \
 test_lock_recovers_dead_nested_steal_chain \
 test_lock_steal_reap_cannot_remove_successor \
 test_lock_reclaims_self_held_steal_mutex \
 test_lock_resumes_own_interrupted_steal_reap \
 test_lock_live_steal_mutex_is_not_reclaimed \
 test_lock_does_not_steal_live_lock \
 test_direct_directory_reaper_cannot_remove_live_successor \
 test_direct_directory_lock_release_and_reap \
 test_link_mode_layout_is_unchanged \
 test_lock_without_real_symlinks \
 test_directory_lock_single_winner_under_load \
 test_dirlock_identity_cases_per_shell \
 test_dirlock_d1b_failed_claim_leaves_generation_to_retirement \
 test_dirlock_d4_crashed_release_is_finished \
 test_dirlock_d4b_handoff_release_recovers_caller \
 test_dirlock_d4c_orphan_husk_cleanup_preserves_successor \
 test_dirlock_d5_orphan_retirement_cannot_touch_successor \
 test_dirlock_d5b_stealer_retires_only_captured_generation \
 test_dirlock_d5c_acquirer_retires_captured_generation \
 test_dirlock_d6_late_publication_is_ordinary_recovery \
 test_dirlock_d7b_bounded_helper_killed_by_deadline \
 test_dirlock_d8_dead_steal_mutex_observers_compose \
 test_dirlock_d8b_reaper_retires_captured_generation \
 test_dirlock_d9_uncommitted_retirement_keeps_record \
 test_dirlock_d10_committed_retirement_is_finished \
 test_dirlock_d11_ambiguous_generation_is_refused \
 test_dirlock_d11b_dead_ambiguous_generation_is_refused \
 test_dirlock_d12_staging_litter_is_never_consulted \
 test_lock_empty_pid_uses_minimum_grace \
 test_lock_late_claim_loses_after_recreate \
 test_lock_paused_mid_acquire_claim_fails_during_steal; do
  printf '\nSCENARIO %s\n' "$scenario"
  "$scenario" || exit $?
done
