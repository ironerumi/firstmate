#!/usr/bin/env bash
set -u
eval "$(python3 - <<'PY'
from pathlib import Path
s = Path('tests/fm-wake-queue.test.sh').read_text()
print(s.split('\ntest_self_held_lock_reclaims_instead_of_deadlocking\n')[0])
PY
)"
test_self_held_lock_reclaims_instead_of_deadlocking
test_lock_wait_returns_when_its_directory_is_removed
test_subshell_lock_ownership_without_bashpid
test_bounded_lock_handoff_after_contention
with_copied_link_locks test_bounded_lock_handoff_after_contention
test_live_presentation_holder_is_deadlined_without_weakening_ack
with_copied_link_locks test_live_presentation_holder_is_deadlined_without_weakening_ack
python3 - "$TMP_ROOT" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
for pattern in ('presentation-lock-deadline*/*.out', 'presentation-lock-deadline*/*.err'):
    for p in sorted(root.glob(pattern)):
        print(f'\n--- product output {p.relative_to(root)} ---')
        print(p.read_text())
PY
