import os
from pathlib import Path
import shutil
import signal
import subprocess

root = Path.cwd()
case = root / '.gate-test-tmp/baseline-cli'
case.mkdir(parents=True)
try:
    oldbin = case / 'upstream/bin'
    shutil.copytree(root / 'bin', oldbin)
    (oldbin / 'fm-wake-lib.sh').write_bytes(subprocess.check_output([
        'git', 'show', '7da4c3621370534ff9689843d2b77f34158057fb:bin/fm-wake-lib.sh']))
    shim = case / 'copy-bin'
    shim.mkdir()
    (shim / 'ln').write_text('#!/usr/bin/env bash\nif [ "$1" = -s ]; then exec cp -R "$2" "$3"; fi\nexec /bin/ln "$@"\n')
    (shim / 'ln').chmod(0o755)
    for label, executable, copying in [
        ('upstream-native', oldbin / 'fm-lock.sh', False),
        ('upstream-copying', oldbin / 'fm-lock.sh', True),
        ('target-copying', root / 'bin/fm-lock.sh', True),
    ]:
        home = case / label
        home.mkdir()
        env = os.environ.copy()
        for key in ['FM_STATE_OVERRIDE', 'FM_ROOT_OVERRIDE', 'FM_DATA_OVERRIDE', 'FM_CONFIG_OVERRIDE', 'FM_PROJECTS_OVERRIDE']:
            env.pop(key, None)
        env['FM_HOME'] = str(home)
        if copying:
            env['PATH'] = str(shim) + os.pathsep + env['PATH']
        p = subprocess.Popen(['bash', str(executable)], env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, start_new_session=True)
        timed_out = False
        try:
            out, err = p.communicate(timeout=6)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(p.pid, signal.SIGKILL)
            out, err = p.communicate()
        print(f'{label}: timed_out={timed_out} exit={p.returncode}', flush=True)
        print('stdout: ' + (out.strip() or '(none)'), flush=True)
        print('stderr: ' + (err.strip() or '(none)'), flush=True)
        if label == 'upstream-copying':
            assert timed_out, 'upstream did not reproduce the copying-link hang'
        else:
            assert not timed_out and p.returncode == 0 and 'lock acquired:' in out
finally:
    shutil.rmtree(case)
