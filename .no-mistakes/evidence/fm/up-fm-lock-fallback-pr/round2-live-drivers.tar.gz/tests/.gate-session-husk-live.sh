#!/usr/bin/env bash
set -u
eval "$(python3 - <<'PY'
from pathlib import Path
print(Path('tests/fm-watcher-lock.test.sh').read_text().split('\ntest_wait_deadline_reaps_a_stopped_child\n')[0])
PY
)"
cli_spawn() {
  local dir=$1 subject=$2 barriers=$3
  mkdir -p "$dir/barrier.$subject"
  PATH="$dir/fakebin:$PATH" FM_HOME="$dir" FM_STATE_OVERRIDE="$dir/state" \
    FM_TEST_SUBJECT="$subject" FM_TEST_BARRIERS="$barriers" \
    FM_TEST_BARRIER_DIR="$dir/barrier.$subject" FM_TEST_EVENTS="$dir/events" \
    FM_TEST_RESUME="$dir/resume.$subject" exec bash "$ROOT/bin/fm-lock.sh" >> "$dir/$subject.log" 2>&1
}
for mode in child boundary reap-child reap-boundary; do
  dir=$(dirlock_case "public-session-husk-$mode")
  lock="$dir/state/.lock.acquire"
  case "$mode" in reap-*)
    FM_HOME="$dir" FM_STATE_OVERRIDE="$dir/state" PATH="$dir/fakebin:$PATH" \
      bash -c '. "$1"; fm_lock_try_create "$2"' _ "$LIB" "$lock" || fail 'could not seed dead claim holder'
    lock="$lock.steal"
  ;; esac
  dirlock_open "$dir" a b c
  cli_spawn "$dir" a "husk:pre:kill:$lock" &
  holder=$!
  dirlock_expect "a husk:pre:$lock" 'CLI releaser did not leave a husk'
  printf 'Public fm-lock releaser killed after retiring its generation: %s\n' "$DIRLOCK_EVENT"
  wait "$holder" 2>/dev/null
  [ -d "$lock" ] && [ -z "$(find "$lock" -mindepth 1 -print)" ] || fail 'not an empty husk'
  touch -t 200001010000 "$lock"
  if [[ "$mode" = *boundary ]]; then
    # Debugger-style breakpoint before the shared removal function is entered.
    # The child resumes the real captured removal operation after its CLI parent dies.
    printf '%s\n' \
      '_gate_debug() {' \
      '  local captured' \
      '  case "$1" in' \
      '    '\''fm_lock_remove_path "$lockdir" "$primary_owner" husk'\'') captured=$primary_owner ;;' \
      '    '\''fm_lock_remove_path "$lockdir" "$owner" husk'\'') captured=$owner ;;' \
      '    *) return 0 ;;' \
      '  esac' \
      '    [ "$lockdir" = "$GATE_TARGET" ] || return 0' \
      '    env -u BASH_ENV FM_TEST_BARRIERS= bash -c '\''' \
      '      . "$1"; shift' \
      '      printf "%s cleanup:pre:%s pid=%s caller=%s\n" "$FM_TEST_SUBJECT" "$1" "$$" "$PPID" >> "$FM_TEST_EVENTS"' \
      '      IFS= read -r _ < "$FM_TEST_RESUME"' \
      '      rc=0; fm_lock_remove_path "$@" || rc=$?' \
      '      printf "%s done rc=%s\n" "$FM_TEST_SUBJECT" "$rc" >> "$FM_TEST_EVENTS"' \
      '      exit "$rc"' \
      '    '\'' _ "$GATE_LIB" "$lockdir" "$captured" husk' \
      '}' \
      'set -T' \
      'trap '\''_gate_debug "$BASH_COMMAND"'\'' DEBUG' > "$dir/debug-env.sh"
    BASH_ENV="$dir/debug-env.sh" GATE_LIB="$LIB" GATE_TARGET="$lock" cli_spawn "$dir" b "" &
  else
    cli_spawn "$dir" b "cleanup:pre:wait:$lock" &
  fi
  acquirer=$!
  dirlock_expect "b cleanup:pre:$lock" 'CLI recovery did not reach the breakpoint'
  printf 'Recovery paused (%s): %s\n' "$mode" "$DIRLOCK_EVENT"
  orphan=$(dirlock_event_field pid)
  [ "$(dirlock_event_field caller)" = "$acquirer" ] || fail 'unexpected cleanup parent'
  kill -KILL "$acquirer"
  wait "$acquirer" 2>/dev/null
  kill -0 "$orphan" || fail 'cleanup child did not outlive CLI parent'
  cli_spawn "$dir" c "retire:pre:wait:$lock" &
  successor=$!
  dirlock_expect "c retire:pre:$lock" 'successor CLI did not acquire and reach release'
  generation=$(dirlock_generation "$lock")
  before=$(dirlock_tree "$dir")
  [ "$(cat "$lock/pid")" = "$successor" ] || fail 'successor identity not published'
  printf 'Successor CLI holds pid=%s generation=%s\n' "$successor" "${generation##*/}"
  printf 'resume\n' >&8
  dirlock_expect 'b done rc=1' 'orphan cleanup did not refuse the complete successor'
  [ "$(cat "$lock/pid")" = "$successor" ] && [ "$(cat "$generation/pid")" = "$successor" ] \
    && [ "$(dirlock_tree "$dir")" = "$before" ] || fail 'orphan modified successor'
  kill -0 "$successor" || fail 'successor no longer live'
  printf 'Resumed orphan refused (rc=1); live successor public pid, generation pid and entire state tree unchanged\n'
  printf 'release\n' >&9
  wait "$successor" || fail 'successor CLI failed to release'
  [ ! -e "$lock" ] || fail 'claim lock residue'
  dirlock_close
  python3 - "$dir/a.log" "$dir/c.log" <<'PY'
from pathlib import Path
import sys
for f in sys.argv[1:]:
    print(Path(f).name+': '+Path(f).read_text().strip())
PY
  printf 'Public session-lock claim fully released (%s)\n\n' "$mode"
done
